# covid19india

<p align="center">
<img src="https://lh3.googleusercontent.com/c1R9ua5XDaInXNNYEVKs5NzwQ36gYCXi1VJ5kLRxGcDYmyUSJM3dnkzqaPWP_CniaHQbQSr4yQqxmsoEGvGFrWFnBRAVjI4=s2560" width="50%">
</p>

<p align="center">
  View our <a href="https://docs.google.com/spreadsheets/d/1nzXUdaIWC84QipdVGUKTiCSc5xntBbpMpzLm6Si33zk">live patient database</a>.  If you'd like to collaborate, join the <a href="https://t.me/covid19indiaops">Telegram Group</a>.
 </p>


## Setup
On Windows
```
npm i && npm run start-win
```
On Linux
```
npm i && npm start
```

## Maintainers
- [jeremyphilemon](https://github.com/jeremyphilemon)

## Contributors
- [s-naveen](https://github.com/jeremyphilemon/covid19-india/pulls?q=is%3Apr+author%3As-naveen+is%3Aclosed)
